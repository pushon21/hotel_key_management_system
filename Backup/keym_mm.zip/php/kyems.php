<?php
/**
 * Created by PhpStorm.
 * User: CosMOs
 * Date: 9/27/2022
 * Time: 6:29 PM
 */

// use mysqli database
// $mysqli = new mysqli

// simple key management system
class keyms{

    public $mysqli;
    public $is_admin = 0;
    public $is_user = 0;


    function __construct(mysqli  $mysqli)
    {
        $this->mysqli = $mysqli;
    }

    function get_key_status($floor,$room){
       $q = $this->mysqli->query("SELECT * FROM `keylogs` where room = '$room' and floor = '$floor' order by id desc limit 1");
       $available = 0;
        while ($row = mysqli_fetch_assoc($q))
        {
            if($row['giveortake'] == 'give') //return
            {
                $available =1;
            }
        }
        return $available;
    }

    /**
     * @param $floor
     * @param $room
     * @param $name
     * @param $doing  Give|take
     */

    function take_key($floor,$room,$name,$doing){
        if($this->get_key_status($floor,$room))
        {
            $time = time();
            $mysqltime = date ('Y-m-d H:i:s');
            $ip = $_SERVER['REMOTE_ADDR'];
            $ua = $this->mysqli->real_escape_string(substr($_SERVER['HTTP_USER_AGENT'],0,500));
            $this->mysqli->query("INSERT INTO `keylogs`(`time`,`tdate`, `name`, `giveortake`, `ip`, `ua`, `floor`, `room`)
 VALUES ('{$time}','{$mysqltime}','{$name}','{$doing}','{$ip}','{$ua}','{$floor}','{$room}')");
            return 1;
        }
        return 0;
    }
    function give_key($floor,$room,$name,$doing){
        if(!$this->get_key_status($floor,$room)){
            $time = time();
            $mysqltime = date ('Y-m-d H:i:s');
            $ip = $_SERVER['REMOTE_ADDR'];
            $ua = $this->mysqli->real_escape_string(substr($_SERVER['HTTP_USER_AGENT'],0,500));
            $this->mysqli->query("INSERT INTO `keylogs`(`time`,`tdate`, `name`, `giveortake`, `ip`, `ua`, `floor`, `room`)
 VALUES ('{$time}','{$mysqltime}','{$name}','{$doing}','{$ip}','{$ua}','{$floor}','{$room}')");
            return 1;
        }
        return 0;
    }

    function get_log_list_html($time = 0,$room = 0,$floor = 0)
    {
        $trs_html = '';
        $q = $this->mysqli->query("SELECT * FROM `keylogs` where room = '$room' and floor = '$floor' order by id");
        while ($row = mysqli_fetch_assoc($q))
        {
            $upload_time = humanTiming($row['time']);
            $taken_by = htmlspecialchars($row['name']);
            $did = $row['giveortake'];
            $roomname = $row['room'];
            $floorname = $row['floor'];
            $date = '';
            $trs_html .= "<tr><td>{$date}</td><td>{$time}</td><td>{$taken_by}</td><td>{$did}</td><td>{$floorname}</td><td>{$roomname}</td></tr>";
        }

    }

    function get_floorrooms_status()
    {
        $sql = "SELECT * FROM keylogs WHERE id IN ( SELECT MAX(id) FROM keylogs GROUP BY room) ORDER BY id DESC;";

        $datum = [];
        $q = $this->mysqli->query($sql);
        while ($row = mysqli_fetch_assoc($q))
        {
            $datum[] = $row;
        }
        return $datum;
    }

// brute force foul coding...
    function ex_get_all_floor()
    {
        $floors = [];
        $sql = "SELECT floor FROM `keylogs` GROUP by floor; ";
        $query = $this->mysqli->query($sql);
        while ($row = mysqli_fetch_assoc($query))
        {
            $floors[] = $row['floor'];
        }
        return $floors;
    }
    function ex_get_all_room($floor)
    {
        $rooms = [];
        $sql = "SELECT room FROM `keylogs` where floor = '{$floor}' GROUP by room; ";
        $query = $this->mysqli->query($sql);
        while ($row = mysqli_fetch_assoc($query))
        {
            $rooms[] = $row['room'];
        }
        return $rooms;
    }

    function ex_check_roomstatus()
    {
        $floors = $this->ex_get_all_floor();
        $all_rooms = [];
        foreach ($floors as  $floor)
        {
            $rooms = $this->ex_get_all_room($floor);
            foreach ($rooms as $room)
            {
                $sql = $this->mysqli->query("SELECT * FROM `keylogs` where floor = '{$floor}' and room = '{$room}' order by id desc limit 1");
                while ($row = mysqli_fetch_assoc($sql))
                {
                   $all_rooms[] = $row;
                }
            }
        }
        return $all_rooms;
    }


    function get_data_by_date($date)
    {
        $data = [];
        $sql = "SELECT * FROM `keylogs` where tdate = '{$date}' order by id asc";
        $query = $this->mysqli->query($sql);
        while ($row = mysqli_fetch_assoc($query))
        {
            $originalDate = $row['tdate'];
            $newDate = date("d/m/Y", strtotime($originalDate));
           // $x =  date('m/d/Y H:i:s', $row['time']);
            $x =  date('H:i:s', $row['time']);
            $row['datetime'] = $x;
            $row['date'] = $newDate;
            $data[] = $row;
        }
        return $data;
    }
}