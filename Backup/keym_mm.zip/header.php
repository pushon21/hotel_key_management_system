<?php
/**
 * Created by PhpStorm.
 * User: CosMOs
 * Date: 9/27/2022
 * Time: 5:19 PM
 */
include_once 'php/config.php';
include_once 'php/functions.php';

echo <<<sfgsdikfdsgfiusioufsgfsdiuufgsdifds

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Key_management_system_Home</title>

    <!-- Goole Fonts -->
    <!-- Icone Fonts -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css" />
    <!-- Main Css -->
    <link rel="stylesheet" href="assets/css/normalize.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/css/normalize.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    
        <!-- All Js File -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr-3.11.2.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="assets/js/keyms.js"></script>
    
  </head>

  <body>
    <section class="main_section">
      <div class="container">
        <div class="responsive_section">
          <div class="header_section">
            <h1>Welcome To The Key Management System</h1>
          </div>

sfgsdikfdsgfiusioufsgfsdiuufgsdifds;
