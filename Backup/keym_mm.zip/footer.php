<?php
/**
 * Created by PhpStorm.
 * User: CosMOs
 * Date: 9/27/2022
 * Time: 5:19 PM
 */


echo <<<sdfhdsioufgdsiufgdsiuyfgsdjcgsdifdsid

        </div>
      </div>
<div class="container">

  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="index.php" class="nav-link px-2 text-muted">Home</a></li>
      <li class="nav-item"><a href="NnT.php" class="nav-link px-2 text-muted">User</a></li>
      <li class="nav-item"><a href="admin_n&t.html" class="nav-link px-2 text-muted">Admin</a></li>
    </ul>
    <p class="text-center text-muted">© 2022 Company, Inc</p>
  </footer>

</div> 
      
      
    </section>

  </body>
</html>

sdfhdsioufgdsiufgdsiuyfgsdjcgsdifdsid;
