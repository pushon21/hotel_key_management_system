<?php
/**
 * Created by PhpStorm.
 * User: CosMOs
 * Date: 9/27/2022
 * Time: 5:22 PM
 */


$is_admin = 0;
$whoami = '';


include_once 'header.php';

echo <<<sdkiufgdsifudsgiufdsxzcjzfxuisdfpfdpgfdphgfdh


          <div class="body_section">
            <div class="image_section">
              <a href="index.php"
                ><img src="assets//Images/key.gif" alt=""
              /></a>
            </div>
            <div class="btn__primary">
              <a href="NnT.php">User</a>
            </div>
            <div class="btn__primary">
              <a href="admin_n&t.html">Admin</a>
            </div>
          </div>
          

sdkiufgdsifudsgiufdsxzcjzfxuisdfpfdpgfdphgfdh;

include_once 'footer.php';